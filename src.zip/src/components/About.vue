<template>
    <div class="about">
        <h1>About this page</h1>
        <p>That just sounds like slavery with extra steps. Yeah, sure, I mean, if you spend all day shuffling words around, you can make anything sound bad. Nothing you do matters, your existence is a lie! I wish that shotgun was my penis.</p>
    </div>
</template>


